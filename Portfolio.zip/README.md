#100daysofCode Challange

First day: (2 June 2017)

Joined the #100daysofCode, I continued to work on my second portfolio website, did a lot of work on the score keeper website to practice JS. Considering to implement bootsraps responsive grid or just make my own for practice.  